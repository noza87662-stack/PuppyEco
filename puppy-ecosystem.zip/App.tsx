
import React, { useEffect } from 'react';
import { useAppStore } from './store';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import Dashboard from './components/Dashboard';
import TaskManager from './components/TaskManager';
import AIChat from './components/AIChat';
import FileManager from './components/FileManager';
import Calendar from './components/Calendar';
import Analytics from './components/Analytics';
import Settings from './components/Settings';
import AuthView from './components/AuthView';

const App: React.FC = () => {
  const { activeTab, isLoggedIn, checkSession } = useAppStore();

  useEffect(() => {
    checkSession();
  }, []);

  if (!isLoggedIn) {
    return <AuthView />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'tasks': return <TaskManager />;
      case 'ai-chat': return <AIChat />;
      case 'files': return <FileManager />;
      case 'calendar': return <Calendar />;
      case 'analytics': return <Analytics />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex bg-[#020617] text-slate-100 overflow-hidden font-sans">
      {/* Background Orbs */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/10 rounded-full blue-glow pointer-events-none"></div>
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/10 rounded-full blue-glow pointer-events-none"></div>

      <Sidebar />
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative z-10">
        <TopBar />
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto h-full animate-in fade-in slide-in-from-bottom-4 duration-500">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
