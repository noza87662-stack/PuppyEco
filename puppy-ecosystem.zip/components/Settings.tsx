
import React, { useState } from 'react';
import { User, Bell, Shield, Palette, HelpCircle, LogOut, ChevronRight, Copy, Check } from 'lucide-react';
import { useAppStore } from '../store';

const Settings: React.FC = () => {
  const { currentUser, logout } = useAppStore();
  const [copied, setCopied] = useState(false);

  if (!currentUser) return null;

  const copyCode = () => {
    if (currentUser.userCode) {
      navigator.clipboard.writeText(currentUser.userCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const settingsSections = [
    { id: 'profile', label: 'Profile Information', icon: User, desc: 'Update your avatar and details' },
    { id: 'notifications', label: 'Notifications', icon: Bell, desc: 'Manage how you receive alerts' },
    { id: 'security', label: 'Privacy & Security', icon: Shield, desc: 'Password and authentication' },
    { id: 'appearance', label: 'Appearance', icon: Palette, desc: 'Theme, colors and fonts' },
    { id: 'support', label: 'Help & Support', icon: HelpCircle, desc: 'Guides and customer service' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-12">
      <div className="glass bg-blue-950/40 p-10 rounded-[48px] flex flex-col md:flex-row items-center gap-10 border border-blue-500/20 shadow-2xl">
        <div className="relative group">
          <img src={currentUser.avatar} className="w-36 h-36 rounded-[32px] object-cover ring-4 ring-blue-500/20 shadow-2xl shadow-blue-900/40" alt="Profile" />
          <button className="absolute -bottom-3 -right-3 bg-blue-600 text-white p-3 rounded-2xl shadow-xl hover:scale-110 transition-all border-4 border-[#020617]">
            <Palette size={18} />
          </button>
        </div>
        <div className="flex-1 text-center md:text-left">
          <div className="flex flex-col md:flex-row md:items-center gap-3 mb-3">
            <h3 className="text-3xl font-bold text-white tracking-tight">{currentUser.name}</h3>
            <span className="bg-blue-500/20 text-blue-400 text-[10px] font-bold uppercase px-3 py-1 rounded-full tracking-widest border border-blue-500/20">
              {currentUser.role}
            </span>
          </div>
          <p className="text-slate-500 font-semibold mb-6">{currentUser.email}</p>
          
          <div className="bg-blue-900/30 border border-blue-500/20 rounded-[24px] p-5 inline-flex items-center gap-6 group hover:bg-blue-900/40 transition-all">
            <div>
              <p className="text-[10px] font-bold text-blue-500 uppercase tracking-[0.2em] mb-1.5">Your User Code</p>
              <p className="text-xl font-mono font-bold text-white tracking-widest">{currentUser.userCode}</p>
            </div>
            <button 
              onClick={copyCode}
              className="p-3 bg-blue-500/10 hover:bg-blue-500/30 rounded-xl transition-all"
            >
              {copied ? <Check size={20} className="text-emerald-400" /> : <Copy size={20} className="text-blue-300" />}
            </button>
          </div>
        </div>
      </div>

      <div className="glass bg-blue-950/40 rounded-[48px] overflow-hidden border border-blue-500/20 shadow-2xl">
        {settingsSections.map((section, idx) => (
          <div key={section.id} className={`p-8 flex items-center justify-between hover:bg-white/5 cursor-pointer transition-all group ${
            idx !== settingsSections.length - 1 ? 'border-b border-blue-900/30' : ''
          }`}>
            <div className="flex items-center gap-6">
              <div className="p-4 bg-blue-900/30 text-blue-400 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-all shadow-lg border border-blue-500/10">
                <section.icon size={24} />
              </div>
              <div>
                <h4 className="font-bold text-base text-white group-hover:text-blue-400 transition-colors">{section.label}</h4>
                <p className="text-sm text-slate-500 mt-1 font-medium">{section.desc}</p>
              </div>
            </div>
            
            <ChevronRight size={22} className="text-slate-700 group-hover:translate-x-2 group-hover:text-blue-400 transition-all" />
          </div>
        ))}
      </div>

      <button 
        onClick={logout}
        className="w-full bg-rose-500/10 text-rose-400 font-bold p-7 rounded-[32px] border border-rose-500/20 flex items-center justify-center gap-3 hover:bg-rose-500/20 transition-all shadow-xl shadow-rose-950/20 group"
      >
        <LogOut size={22} className="group-hover:-translate-x-1 transition-transform" />
        <span className="tracking-widest uppercase text-xs font-bold">Sign Out from Puppy Ecosystem</span>
      </button>
    </div>
  );
};

export default Settings;
