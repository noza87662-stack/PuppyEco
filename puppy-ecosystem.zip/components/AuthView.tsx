
import React, { useState } from 'react';
import { Dog, Key, Mail, User as UserIcon, ArrowRight, Copy, Check } from 'lucide-react';
import { useAppStore } from '../store';

const AuthView: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const { registerUser, loginUser } = useAppStore();

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) {
      setError('Please fill in all fields');
      return;
    }
    const newCode = registerUser(name, email);
    setGeneratedCode(newCode);
    setError('');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code) {
      setError('Enter your User Code');
      return;
    }
    const success = loginUser(code);
    if (!success) {
      setError('Invalid User Code');
    }
  };

  const copyToClipboard = () => {
    if (generatedCode) {
      navigator.clipboard.writeText(generatedCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#020617] text-white p-4 relative overflow-hidden">
      {/* Dynamic Background */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-700/20 rounded-full blue-glow pointer-events-none"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-indigo-700/10 rounded-full blue-glow pointer-events-none"></div>

      <div className="w-full max-w-lg relative z-10 animate-in fade-in zoom-in duration-1000">
        <div className="flex flex-col items-center mb-10">
          <div className="bg-blue-600 p-5 rounded-[28px] text-white shadow-2xl shadow-blue-500/30 mb-6 scale-110">
            <Dog size={48} />
          </div>
          <h1 className="font-poppins font-bold text-5xl tracking-tight text-white">
            Puppy<span className="text-blue-400">Eco</span>
          </h1>
          <p className="text-slate-500 mt-4 font-semibold uppercase tracking-[0.2em] text-xs">Harmony in your workspace</p>
        </div>

        <div className="glass bg-blue-950/40 backdrop-blur-2xl border border-blue-500/20 rounded-[48px] p-10 md:p-12 shadow-2xl">
          {generatedCode ? (
            <div className="text-center animate-in slide-in-from-right-10 duration-500">
              <h2 className="text-3xl font-bold mb-6">Welcome to the pack!</h2>
              <p className="text-slate-400 text-sm leading-relaxed mb-8">Your profile is ready. Use this unique code to access your workspace. <span className="text-blue-400 font-bold">Save it carefully.</span></p>
              
              <div className="bg-blue-900/30 border border-blue-500/20 p-8 rounded-[32px] mb-8 group flex items-center justify-between hover:bg-blue-900/40 transition-all">
                <span className="text-4xl font-mono font-bold tracking-[0.2em] text-blue-400">{generatedCode}</span>
                <button 
                  onClick={copyToClipboard}
                  className="p-4 bg-blue-500/20 hover:bg-blue-500/40 rounded-2xl transition-all"
                >
                  {copied ? <Check size={24} className="text-emerald-400" /> : <Copy size={24} className="text-blue-200" />}
                </button>
              </div>

              <button 
                onClick={() => { setIsLogin(true); setGeneratedCode(null); setCode(generatedCode); }}
                className="w-full bg-blue-600 py-5 rounded-2xl font-bold text-lg hover:bg-blue-500 transition-all flex items-center justify-center gap-3 shadow-xl shadow-blue-600/20"
              >
                Access Dashboard <ArrowRight size={22} />
              </button>
            </div>
          ) : (
            <>
              <div className="flex bg-blue-900/20 p-1.5 rounded-[24px] mb-10">
                <button 
                  onClick={() => { setIsLogin(true); setError(''); }}
                  className={`flex-1 py-3 rounded-[20px] text-sm font-bold transition-all ${isLogin ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Login
                </button>
                <button 
                  onClick={() => { setIsLogin(false); setError(''); }}
                  className={`flex-1 py-3 rounded-[20px] text-sm font-bold transition-all ${!isLogin ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Register
                </button>
              </div>

              <form onSubmit={isLogin ? handleLogin : handleRegister} className="space-y-5">
                {error && (
                  <div className="bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs p-4 rounded-2xl animate-shake font-bold text-center">
                    {error}
                  </div>
                )}

                {!isLogin && (
                  <>
                    <div className="relative group">
                      <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={20} />
                      <input 
                        type="text" 
                        placeholder="Full Name" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-blue-900/20 border border-blue-500/10 rounded-2xl py-5 pl-14 pr-6 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:bg-blue-900/40 transition-all placeholder:text-slate-600"
                      />
                    </div>
                    <div className="relative group">
                      <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={20} />
                      <input 
                        type="email" 
                        placeholder="Email Address" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-blue-900/20 border border-blue-500/10 rounded-2xl py-5 pl-14 pr-6 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:bg-blue-900/40 transition-all placeholder:text-slate-600"
                      />
                    </div>
                  </>
                )}

                {isLogin && (
                  <div className="relative group">
                    <Key className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={20} />
                    <input 
                      type="text" 
                      placeholder="Enter User Code" 
                      value={code}
                      onChange={(e) => setCode(e.target.value.toUpperCase())}
                      className="w-full bg-blue-900/20 border border-blue-500/10 rounded-2xl py-5 pl-14 pr-6 text-sm font-mono tracking-[0.2em] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:bg-blue-900/40 transition-all placeholder:text-slate-600"
                    />
                  </div>
                )}

                <button className="w-full bg-blue-600 py-5 rounded-2xl font-bold text-lg hover:bg-blue-500 active:scale-[0.98] transition-all shadow-xl shadow-blue-600/30 mt-6 text-white">
                  {isLogin ? 'Sign In' : 'Create Account'}
                </button>
              </form>
              
              <div className="mt-8 text-center">
                <p className="text-slate-600 text-[10px] font-bold uppercase tracking-[0.2em]">Secured by Puppy Ecosystem Encryption</p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthView;
