
import React from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';

const Calendar: React.FC = () => {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const date = new Date();
  const currentMonth = date.toLocaleString('default', { month: 'long' });
  const currentYear = date.getFullYear();

  // Simple mock of a 30-day month starting on Friday (just for visual representation)
  const daysInMonth = 30;
  const startDay = 5; 

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <h3 className="font-poppins font-bold text-2xl">{currentMonth} {currentYear}</h3>
          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
            <button className="p-2 hover:text-orange-500"><ChevronLeft size={20}/></button>
            <div className="w-px h-6 bg-slate-200 dark:bg-slate-800"></div>
            <button className="p-2 hover:text-orange-500"><ChevronRight size={20}/></button>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-sm font-bold">
            <button className="px-4 py-1.5 bg-white dark:bg-slate-700 shadow-sm rounded-lg text-orange-500">Month</button>
            <button className="px-4 py-1.5 text-slate-500">Week</button>
            <button className="px-4 py-1.5 text-slate-500">Day</button>
          </div>
          <button className="bg-orange-500 text-white p-2.5 rounded-xl shadow-lg shadow-orange-500/20 hover:scale-105 transition-transform">
            <Plus size={20} />
          </button>
        </div>
      </div>

      <div className="flex-1 glass rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 flex flex-col">
        <div className="grid grid-cols-7 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-800">
          {days.map(day => (
            <div key={day} className="py-3 text-center text-xs font-bold text-slate-400 uppercase tracking-widest border-r border-slate-200 dark:border-slate-800 last:border-r-0">
              {day}
            </div>
          ))}
        </div>

        <div className="flex-1 grid grid-cols-7">
          {/* Empty blocks for start of month */}
          {Array.from({ length: startDay }).map((_, i) => (
            <div key={`empty-${i}`} className="border-r border-b border-slate-200 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/10"></div>
          ))}

          {/* Day blocks */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const hasEvent = dayNum === 12 || dayNum === 15 || dayNum === 24;
            const isToday = dayNum === date.getDate();

            return (
              <div key={dayNum} className="group min-h-[100px] p-2 border-r border-b border-slate-200 dark:border-slate-800 relative hover:bg-white dark:hover:bg-slate-800/50 transition-colors">
                <span className={`inline-flex items-center justify-center w-7 h-7 text-xs font-bold rounded-full ${
                  isToday ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30' : 'text-slate-700 dark:text-slate-300'
                }`}>
                  {dayNum}
                </span>

                <div className="mt-2 space-y-1">
                  {hasEvent && (
                    <div className={`text-[10px] font-bold p-1 rounded-lg truncate ${
                      dayNum === 24 ? 'bg-orange-100 text-orange-600 dark:bg-orange-900/40' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/40'
                    }`}>
                      {dayNum === 24 ? 'Christmas Eve' : 'Design Sync'}
                    </div>
                  )}
                  {dayNum === 12 && (
                    <div className="text-[10px] font-bold p-1 rounded-lg truncate bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40">
                      Puppy Eco Launch
                    </div>
                  )}
                </div>

                <button className="absolute bottom-2 right-2 p-1 rounded bg-slate-100 dark:bg-slate-700 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity hover:text-orange-500">
                  <Plus size={12} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Calendar;
