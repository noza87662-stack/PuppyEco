
import React, { useState } from 'react';
import { Plus, MoreHorizontal, Calendar, AlertCircle, CheckCircle2, Search, Filter, Dog } from 'lucide-react';
import { useAppStore } from '../store';
import { Task } from '../types';

const TaskManager: React.FC = () => {
  const { tasks, updateTask, addTask } = useAppStore();
  const [isAdding, setIsAdding] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');

  const columns: Task['status'][] = ['Todo', 'In Progress', 'Done'];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-rose-500/20 text-rose-400 border border-rose-500/20';
      case 'Medium': return 'bg-blue-500/20 text-blue-300 border border-blue-500/20';
      case 'Low': return 'bg-slate-500/20 text-slate-400 border border-slate-500/20';
      default: return 'bg-blue-900/30 text-slate-400';
    }
  };

  const handleAddNewTask = () => {
    if (!newTaskTitle.trim()) return;
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTaskTitle,
      description: '',
      priority: 'Medium',
      status: 'Todo',
      dueDate: new Date().toISOString().split('T')[0]
    };
    addTask(newTask);
    setNewTaskTitle('');
    setIsAdding(false);
  };

  return (
    <div className="h-full flex flex-col gap-8">
      {/* Task Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Filter tasks..." 
              className="pl-12 pr-6 py-3 bg-blue-950/30 border border-blue-900/30 rounded-2xl text-sm w-72 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:bg-blue-950/50 transition-all placeholder:text-slate-600 text-slate-200"
            />
          </div>
          <button className="p-3 border border-blue-900/30 bg-blue-950/30 rounded-2xl text-slate-500 hover:text-blue-400 hover:bg-blue-900/40 transition-all">
            <Filter size={20} />
          </button>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 text-white px-8 py-3.5 rounded-[20px] font-bold flex items-center justify-center gap-3 hover:bg-blue-500 transition-all shadow-xl shadow-blue-600/20 active:scale-95"
        >
          <Plus size={22} />
          <span>New Task</span>
        </button>
      </div>

      {/* Kanban Board */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8 overflow-x-auto min-h-0 pb-6 custom-scroll">
        {columns.map(status => (
          <div key={status} className="flex flex-col min-w-[340px]">
            <div className="flex items-center justify-between mb-6 px-3">
              <div className="flex items-center gap-3">
                <h3 className="font-bold text-white text-base tracking-tight">{status}</h3>
                <span className="bg-blue-900/40 border border-blue-500/10 px-3 py-1 rounded-full text-[11px] font-bold text-blue-400 shadow-inner">
                  {tasks.filter(t => t.status === status).length}
                </span>
              </div>
              <button className="text-slate-600 hover:text-blue-400 transition-colors"><MoreHorizontal size={20}/></button>
            </div>

            <div className="flex-1 bg-blue-950/20 border border-blue-900/20 rounded-[32px] p-5 space-y-5 overflow-y-auto backdrop-blur-sm">
              {status === 'Todo' && isAdding && (
                <div className="glass bg-blue-900/40 p-5 rounded-[24px] border border-blue-400/20 animate-in fade-in slide-in-from-top-4 duration-300">
                  <input
                    autoFocus
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddNewTask()}
                    placeholder="Task title..."
                    className="w-full bg-transparent border-none outline-none font-bold text-white mb-4 placeholder:text-slate-600"
                  />
                  <div className="flex justify-end gap-3">
                    <button onClick={() => setIsAdding(false)} className="text-xs font-bold text-slate-500 px-4 py-2 hover:bg-white/5 rounded-xl transition-all">Cancel</button>
                    <button onClick={handleAddNewTask} className="text-xs font-bold bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-500 shadow-lg shadow-blue-900/20 transition-all">Add</button>
                  </div>
                </div>
              )}

              {tasks.filter(t => t.status === status).map(task => (
                <div 
                  key={task.id} 
                  className="glass bg-blue-900/20 p-6 rounded-[28px] group relative hover:scale-[1.02] hover:border-blue-500/30 hover:shadow-2xl hover:shadow-blue-950/40 transition-all cursor-grab active:cursor-grabbing"
                >
                  <div className="flex justify-between items-start mb-4">
                    <span className={`text-[10px] font-bold uppercase tracking-[0.15em] px-3 py-1 rounded-lg ${getPriorityColor(task.priority)}`}>
                      {task.priority}
                    </span>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                      {status !== 'Done' && (
                        <button 
                          onClick={() => updateTask(task.id, { status: status === 'Todo' ? 'In Progress' : 'Done' })}
                          className="p-1.5 bg-blue-500/10 hover:bg-blue-500/30 rounded-xl text-emerald-400 transition-all"
                        >
                          <CheckCircle2 size={18} />
                        </button>
                      )}
                    </div>
                  </div>
                  <h4 className="font-bold text-slate-100 mb-3 group-hover:text-blue-400 transition-colors leading-snug">{task.title}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mb-6 leading-relaxed font-medium">{task.description || 'Focus on details and deliver paws-itive results.'}</p>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-blue-900/20">
                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar size={14} className="text-blue-500" />
                      <span className="text-[10px] font-bold uppercase tracking-widest">{task.dueDate}</span>
                    </div>
                    <div className="flex -space-x-2">
                      <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=user1" className="w-7 h-7 rounded-xl border-2 border-[#020617] object-cover" alt="avatar" />
                      <div className="w-7 h-7 rounded-xl bg-blue-600 text-[9px] flex items-center justify-center text-white border-2 border-[#020617] font-bold shadow-lg shadow-blue-900/20">+2</div>
                    </div>
                  </div>
                </div>
              ))}

              {tasks.filter(t => t.status === status).length === 0 && !isAdding && (
                <div className="h-32 flex flex-col items-center justify-center border-2 border-dashed border-blue-900/20 rounded-[28px] text-slate-700">
                   {/* Added Dog to imports above to fix line 134 error */}
                   <Dog size={24} className="opacity-10 mb-2" />
                   <span className="text-xs font-bold uppercase tracking-widest opacity-30">Clear Zone</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskManager;
