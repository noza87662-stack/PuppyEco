
import React from 'react';
import { FileText, Folder, Image, MoreVertical, Search, Upload, Download, Trash2, LayoutGrid, List } from 'lucide-react';
import { useAppStore } from '../store';

const FileManager: React.FC = () => {
  const { files } = useAppStore();

  const getIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="text-rose-500" />;
      case 'image': return <Image className="text-blue-500" />;
      case 'folder': return <Folder className="text-amber-500" fill="currentColor" fillOpacity={0.2} />;
      default: return <FileText className="text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search files..." 
              className="pl-10 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/30"
            />
          </div>
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            <button className="p-1.5 bg-white dark:bg-slate-700 shadow-sm rounded-lg text-orange-500"><LayoutGrid size={18}/></button>
            <button className="p-1.5 text-slate-500"><List size={18}/></button>
          </div>
        </div>
        <button className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all">
          <Upload size={20} />
          <span>Upload New</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {files.map(file => (
          <div key={file.id} className="glass p-4 rounded-3xl group relative hover:scale-[1.02] transition-all cursor-pointer">
            <div className="flex justify-between items-start mb-6">
              <div className="p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm group-hover:shadow-md transition-shadow">
                {getIcon(file.type)}
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                <button className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-slate-400 hover:text-orange-500"><Download size={16}/></button>
                <button className="p-1.5 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg text-slate-400 hover:text-rose-500"><Trash2 size={16}/></button>
              </div>
            </div>
            
            <h4 className="font-bold text-sm mb-1 truncate">{file.name}</h4>
            <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
              <span>{file.size}</span>
              <span>{file.lastModified}</span>
            </div>

            {file.type === 'image' && (
              <div className="mt-4 rounded-2xl overflow-hidden h-32 bg-slate-100 dark:bg-slate-800">
                <img src={`https://picsum.photos/seed/${file.id}/400/300`} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt="preview" />
              </div>
            )}
          </div>
        ))}

        <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 p-6 rounded-3xl flex flex-col items-center justify-center gap-3 text-slate-400 hover:border-orange-500 hover:text-orange-500 transition-all cursor-pointer group">
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-full group-hover:bg-orange-50 dark:group-hover:bg-orange-900/20">
            <Upload size={24} />
          </div>
          <span className="text-sm font-bold">Add File</span>
        </div>
      </div>
    </div>
  );
};

export default FileManager;
