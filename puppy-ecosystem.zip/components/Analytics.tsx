
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Target, Zap, Clock, Users } from 'lucide-react';

const Analytics: React.FC = () => {
  const trendData = [
    { name: 'Week 1', productivity: 65, focus: 40 },
    { name: 'Week 2', productivity: 78, focus: 55 },
    { name: 'Week 3', productivity: 72, focus: 60 },
    { name: 'Week 4', productivity: 90, focus: 85 },
  ];

  const skillData = [
    { subject: 'Coding', A: 120, B: 110, fullMark: 150 },
    { subject: 'UI Design', A: 98, B: 130, fullMark: 150 },
    { subject: 'Logic', A: 86, B: 130, fullMark: 150 },
    { subject: 'Creativity', A: 99, B: 100, fullMark: 150 },
    { subject: 'Writing', A: 85, B: 90, fullMark: 150 },
    { subject: 'Speed', A: 65, B: 85, fullMark: 150 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Avg Productivity', value: '84%', icon: Zap, color: 'text-orange-500', bg: 'bg-orange-50' },
          { label: 'Work Efficiency', value: '1.2x', icon: Target, color: 'text-emerald-500', bg: 'bg-emerald-50' },
          { label: 'Active Hours', value: '142h', icon: Clock, color: 'text-blue-500', bg: 'bg-blue-50' },
          { label: 'Team Influence', value: 'Top 5%', icon: Users, color: 'text-purple-500', bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <div key={i} className="glass p-6 rounded-3xl">
            <div className={`p-3 rounded-2xl w-fit ${stat.bg} dark:bg-slate-800 ${stat.color} mb-4`}>
              <stat.icon size={24} />
            </div>
            <p className="text-sm font-semibold text-slate-500">{stat.label}</p>
            <h3 className="text-3xl font-bold mt-1 tracking-tight">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass p-8 rounded-3xl">
          <h4 className="font-bold text-lg mb-8">Performance Trend</h4>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorProd" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                <Area type="monotone" dataKey="productivity" stroke="#f97316" strokeWidth={3} fillOpacity={1} fill="url(#colorProd)" />
                <Area type="monotone" dataKey="focus" stroke="#6366f1" strokeWidth={3} fill="transparent" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-8 rounded-3xl">
          <h4 className="font-bold text-lg mb-8">Skill Distribution</h4>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={skillData}>
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{fill: '#94a3b8', fontSize: 10}} />
                <PolarRadiusAxis angle={30} domain={[0, 150]} axisLine={false} tick={false} />
                <Radar name="User A" dataKey="A" stroke="#f97316" fill="#f97316" fillOpacity={0.6} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
