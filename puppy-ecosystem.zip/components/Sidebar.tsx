
import React from 'react';
import { LayoutDashboard, CheckSquare, MessageCircle, Files, Calendar, BarChart3, Settings, Dog } from 'lucide-react';
import { useAppStore } from '../store';
import { TabType } from '../types';

const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab } = useAppStore();

  const menuItems = [
    { id: 'dashboard' as TabType, icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'tasks' as TabType, icon: CheckSquare, label: 'Tasks' },
    { id: 'ai-chat' as TabType, icon: MessageCircle, label: 'Puppy Bot' },
    { id: 'files' as TabType, icon: Files, label: 'Files' },
    { id: 'calendar' as TabType, icon: Calendar, label: 'Calendar' },
    { id: 'analytics' as TabType, icon: BarChart3, label: 'Analytics' },
    { id: 'settings' as TabType, icon: Settings, label: 'Settings' },
  ];

  return (
    <aside className="w-20 md:w-64 flex flex-col h-screen border-r border-blue-900/30 bg-[#020617]/50 backdrop-blur-xl transition-all duration-300 relative z-20">
      <div className="p-8 flex items-center gap-3">
        <div className="bg-blue-600 p-2.5 rounded-2xl text-white shadow-lg shadow-blue-500/20">
          <Dog size={24} />
        </div>
        <span className="font-poppins font-bold text-xl hidden md:block tracking-tight text-white">
          Puppy<span className="text-blue-400">Eco</span>
        </span>
      </div>

      <nav className="flex-1 px-4 space-y-1.5 mt-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all group ${
              activeTab === item.id 
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' 
              : 'text-slate-400 hover:bg-white/5 hover:text-slate-100'
            }`}
          >
            <item.icon size={20} className={`${activeTab === item.id ? 'scale-110' : 'group-hover:scale-110'} transition-transform`} />
            <span className="hidden md:block font-semibold text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6">
        <div className="glass bg-blue-900/20 p-5 rounded-[24px] border border-blue-500/10 hidden md:block">
          <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-2">Pro Plan</p>
          <p className="text-sm font-medium text-slate-300 leading-snug mb-4">Unleash full potential with Puppy Pro.</p>
          <button className="w-full bg-blue-600 text-white py-2.5 rounded-xl text-xs font-bold hover:bg-blue-500 transition-colors shadow-lg shadow-blue-950/20">
            Upgrade Now
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
