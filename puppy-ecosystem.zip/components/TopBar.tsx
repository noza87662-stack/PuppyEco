
import React from 'react';
import { Search, Bell, Moon, Sun } from 'lucide-react';
import { useAppStore } from '../store';

const TopBar: React.FC = () => {
  const { currentUser, activeTab } = useAppStore();

  if (!currentUser) return null;

  const getTitle = () => {
    const titles: Record<string, string> = {
      dashboard: 'Overview',
      tasks: 'My Workspace',
      'ai-chat': 'Emotional Assistant',
      files: 'Drive',
      calendar: 'Planner',
      analytics: 'Insights',
      settings: 'Preferences'
    };
    return titles[activeTab] || 'Puppy Eco';
  };

  return (
    <header className="h-20 border-b border-blue-900/20 bg-[#020617]/40 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-10">
      <h2 className="font-poppins font-bold text-xl md:text-2xl tracking-tight text-white">{getTitle()}</h2>

      <div className="flex items-center gap-2 md:gap-6">
        <div className="hidden lg:flex items-center relative group">
          <Search size={18} className="absolute left-4 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
          <input 
            type="text" 
            placeholder="Quick search..." 
            className="pl-12 pr-4 py-2.5 bg-blue-950/30 border border-blue-900/30 rounded-2xl text-sm w-72 text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:bg-blue-950/50 transition-all placeholder:text-slate-600"
          />
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2.5 hover:bg-white/5 rounded-2xl transition-all text-slate-400 hover:text-blue-400">
            <Sun size={20} />
          </button>
          
          <button className="p-2.5 hover:bg-white/5 rounded-2xl transition-all text-slate-400 hover:text-blue-400 relative">
            <Bell size={20} />
            <span className="absolute top-3 right-3 w-2 h-2 bg-blue-400 rounded-full border-2 border-[#020617]"></span>
          </button>

          <div className="w-px h-8 bg-blue-900/30 mx-2 hidden md:block"></div>

          <div className="flex items-center gap-3 pl-2 group cursor-pointer">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-100 leading-none">{currentUser.name}</p>
              <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mt-1.5">{currentUser.role}</p>
            </div>
            <img src={currentUser.avatar} alt="Avatar" className="w-11 h-11 rounded-2xl object-cover ring-2 ring-blue-900/30 group-hover:ring-blue-500/50 transition-all" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;
