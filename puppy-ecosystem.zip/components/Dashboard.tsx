
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, Tooltip } from 'recharts';
import { ArrowUpRight, Clock, CheckCircle, Flame, Calendar as CalIcon, TrendingUp, Dog } from 'lucide-react';
import { useAppStore } from '../store';

const Dashboard: React.FC = () => {
  const { tasks } = useAppStore();

  const productivityData = [
    { name: 'Mon', tasks: 4 },
    { name: 'Tue', tasks: 7 },
    { name: 'Wed', tasks: 5 },
    { name: 'Thu', tasks: 8 },
    { name: 'Fri', tasks: 12 },
    { name: 'Sat', tasks: 3 },
    { name: 'Sun', tasks: 1 },
  ];

  const statusData = [
    { name: 'Done', value: tasks.filter(t => t.status === 'Done').length },
    { name: 'In Progress', value: tasks.filter(t => t.status === 'In Progress').length },
    { name: 'Todo', value: tasks.filter(t => t.status === 'Todo').length },
  ];

  const COLORS = ['#3b82f6', '#60a5fa', '#1d4ed8'];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Stats Cards */}
      <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Clock, label: 'Focused Hours', value: '42.5', change: '+12%', color: 'blue' },
          { icon: CheckCircle, label: 'Completed Tasks', value: statusData[0].value.toString(), change: '+4', color: 'indigo' },
          { icon: Flame, label: 'Work Streak', value: '12 Days', change: null, color: 'sky' },
          { icon: CalIcon, label: 'Upcoming Events', value: '3', change: null, color: 'blue' },
        ].map((stat, i) => (
          <div key={i} className="glass p-7 rounded-[32px] hover:scale-[1.02] transition-all group">
            <div className="flex justify-between items-start mb-5">
              <div className="p-3 bg-blue-600/20 text-blue-400 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-all">
                <stat.icon size={22} />
              </div>
              {stat.change && (
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg flex items-center gap-1">
                  {stat.change} <ArrowUpRight size={12} />
                </span>
              )}
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">{stat.label}</p>
            <h3 className="text-3xl font-bold mt-2 text-white">{stat.value}</h3>
          </div>
        ))}
      </div>

      {/* Main Charts Area */}
      <div className="lg:col-span-2 space-y-8">
        <div className="glass p-8 rounded-[40px]">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h4 className="font-bold text-lg text-white">Productivity Flow</h4>
              <p className="text-sm text-slate-500 mt-1">Activity metrics this week</p>
            </div>
            <button className="flex items-center gap-2 text-xs font-bold text-blue-400 hover:text-blue-300 transition-colors uppercase tracking-widest">
              Detailed View <TrendingUp size={14} />
            </button>
          </div>
          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productivityData}>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 11, fontWeight: 600}} />
                <Tooltip 
                  cursor={{fill: 'rgba(59, 130, 246, 0.05)'}} 
                  contentStyle={{background: '#0f172a', borderRadius: '16px', border: '1px solid rgba(59, 130, 246, 0.2)', color: '#fff'}} 
                />
                <Bar dataKey="tasks" fill="#3b82f6" radius={[8, 8, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-8 rounded-[40px]">
          <h4 className="font-bold text-lg text-white mb-8">Recent Pipeline</h4>
          <div className="space-y-4">
            {tasks.slice(0, 3).map((task, idx) => (
              <div key={task.id} className="flex items-center gap-5 p-4 rounded-[24px] hover:bg-white/5 transition-all group">
                <div className={`w-1.5 h-12 rounded-full ${idx === 0 ? 'bg-blue-500' : 'bg-indigo-500'}`}></div>
                <div className="flex-1">
                  <p className="font-bold text-slate-100 group-hover:text-blue-400 transition-colors">{task.title}</p>
                  <p className="text-xs text-slate-500 mt-1 font-medium">{task.status}</p>
                </div>
                <span className="text-[10px] text-slate-600 font-bold">2h ago</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sidebar Area */}
      <div className="space-y-8">
        <div className="glass p-8 rounded-[40px]">
          <h4 className="font-bold text-lg text-white mb-4">Task Allocation</h4>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-col gap-3 mt-6">
            {statusData.map((s, i) => (
              <div key={s.name} className="flex items-center justify-between p-2 rounded-xl bg-blue-900/10 border border-blue-900/20">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" style={{backgroundColor: COLORS[i]}}></div>
                  <span className="text-xs text-slate-400 font-semibold">{s.name}</span>
                </div>
                <span className="text-xs font-bold text-slate-200">{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[40px] text-white relative overflow-hidden group shadow-2xl shadow-blue-900/40">
          <Dog size={160} className="absolute -bottom-12 -right-12 opacity-10 transform group-hover:scale-110 group-hover:-rotate-12 transition-all duration-700" />
          <h4 className="text-xl font-bold mb-3">Work Stress?</h4>
          <p className="text-sm opacity-80 leading-relaxed mb-8">I'm here to listen and help you stay on track. Let's talk!</p>
          <button className="w-full bg-white text-blue-600 px-6 py-3.5 rounded-2xl text-sm font-bold shadow-lg shadow-blue-900/20 hover:bg-blue-50 transition-all active:scale-95">
            Bark to Puppy Bot
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
