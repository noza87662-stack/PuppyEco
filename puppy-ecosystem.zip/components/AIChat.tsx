
import React, { useState, useRef, useEffect } from 'react';
import { Send, Dog, Sparkles, Smile, MessageSquare, Info } from 'lucide-react';
import { useAppStore } from '../store';
import { getPuppyResponse } from '../gemini';

const AIChat: React.FC = () => {
  const { messages, addMessage } = useAppStore();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = { id: Date.now().toString(), role: 'user' as const, content: input, timestamp: new Date() };
    addMessage(userMsg);
    setInput('');
    setIsLoading(true);

    const history = messages.map(m => ({ role: m.role, content: m.content }));
    const responseText = await getPuppyResponse(input, history);

    const botMsg = { id: (Date.now() + 1).toString(), role: 'assistant' as const, content: responseText, timestamp: new Date() };
    addMessage(botMsg);
    setIsLoading(false);
  };

  return (
    <div className="h-[calc(100vh-12rem)] flex gap-8">
      <div className="flex-1 flex flex-col glass rounded-[40px] overflow-hidden shadow-2xl shadow-blue-950/20">
        {/* Chat Header */}
        <div className="p-6 border-b border-blue-900/20 flex items-center justify-between bg-blue-950/30">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-600 rounded-[20px] flex items-center justify-center text-white shadow-lg shadow-blue-600/20">
              <Dog size={24} />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Puppy Bot</h3>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(96,165,250,0.8)]"></span>
                <span className="text-xs text-slate-500 font-bold uppercase tracking-widest">Listening carefully</span>
              </div>
            </div>
          </div>
          <button className="p-3 hover:bg-white/5 rounded-2xl text-slate-400 hover:text-blue-400 transition-all">
            <Info size={20} />
          </button>
        </div>

        {/* Chat Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth bg-blue-950/10">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                {msg.role === 'assistant' && (
                  <div className="w-9 h-9 rounded-2xl bg-blue-900/40 flex-shrink-0 flex items-center justify-center text-blue-400 border border-blue-500/20">
                    <Dog size={18} />
                  </div>
                )}
                <div className={`p-5 rounded-[28px] text-sm leading-relaxed shadow-lg ${
                  msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none shadow-blue-900/20' 
                  : 'bg-blue-900/40 text-slate-100 rounded-tl-none border border-blue-500/10 backdrop-blur-md'
                }`}>
                  {msg.content}
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-blue-900/40 p-5 rounded-[28px] rounded-tl-none border border-blue-500/10">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-75"></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-150"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Chat Input */}
        <div className="p-6 bg-blue-950/30 border-t border-blue-900/20">
          <div className="flex items-center gap-3 p-2 bg-blue-900/20 border border-blue-500/10 rounded-[28px] focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
            <button className="p-3 text-slate-500 hover:text-blue-400 hover:bg-white/5 rounded-2xl transition-all">
              <Smile size={22} />
            </button>
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="What's on your mind? I'm here to support you..."
              className="flex-1 bg-transparent border-none outline-none text-sm px-2 text-white placeholder:text-slate-600"
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-3.5 bg-blue-600 text-white rounded-[20px] shadow-xl shadow-blue-600/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 disabled:shadow-none"
            >
              <Send size={20} />
            </button>
          </div>
          <p className="text-[10px] text-center text-slate-600 font-bold uppercase tracking-widest mt-4">
            AI Assistant tuned for empathy & productivity
          </p>
        </div>
      </div>

      {/* Helpful Sidebar */}
      <div className="hidden xl:flex w-80 flex-col gap-8">
        <div className="glass p-8 rounded-[40px]">
          <h4 className="font-bold mb-6 flex items-center gap-3 text-white">
            <Sparkles size={20} className="text-blue-400" />
            Vibe Check
          </h4>
          <div className="space-y-6">
            <div className="bg-blue-600/10 p-5 rounded-[24px] border border-blue-500/20">
              <p className="text-[10px] font-bold text-blue-400 mb-2 uppercase tracking-widest">CURRENT MOOD</p>
              <p className="text-sm font-semibold text-slate-200 leading-relaxed">You seem highly productive. The pack is proud of you!</p>
            </div>
            <div className="p-5 rounded-[24px] bg-white/5 border border-white/5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-[18px] bg-blue-900/40 flex items-center justify-center text-blue-400 border border-blue-500/10">
                <MessageSquare size={20} />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">TOTAL CHATS</p>
                <p className="text-xl font-bold text-white">128</p>
              </div>
            </div>
          </div>
        </div>

        <div className="glass p-8 rounded-[40px] flex-1">
          <h4 className="font-bold text-white mb-6">Daily Support Tips</h4>
          <ul className="space-y-5">
            {[
              "Take a 5-minute 'Sniff Break' every hour.",
              "Hydrate! Pups always need water.",
              "Celebrate the small wins with a treat.",
              "Focus on one 'Big Bone' task at a time."
            ].map((tip, i) => (
              <li key={i} className="flex gap-4 text-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 flex-shrink-0"></div>
                <span className="text-slate-400 font-medium leading-relaxed">{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AIChat;
