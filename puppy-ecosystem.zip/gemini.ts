
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
You are "Puppy Bot", an empathetic and cheerful AI assistant within the Puppy Ecosystem SaaS platform.
Your goal is to support the user both professionally and emotionally.
Characteristics:
- You use puppy-themed metaphors occasionally (e.g., "paws-itive vibes", "digging into the data").
- You are extremely supportive, noticing if a user seems stressed.
- You provide concise but helpful productivity tips.
- You act like a loyal companion.
- Your tone is friendly, warm, and professional yet slightly playful.
- If a user reports high workload, suggest a short "mental walk" or a stretch.
`;

export const getPuppyResponse = async (userPrompt: string, history: { role: string, content: string }[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';

    const contents = history.map(h => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: h.content }]
    }));

    contents.push({
      role: 'user',
      parts: [{ text: userPrompt }]
    });

    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.8,
        topP: 0.95,
      }
    });

    return response.text || "Woof! Something went wrong with my barks. Please try again!";
  } catch (error) {
    console.error("Puppy Bot Error:", error);
    return "I'm having a little trouble connecting to the park. Check your connection!";
  }
};
