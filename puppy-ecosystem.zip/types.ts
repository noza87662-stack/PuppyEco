
export type TabType = 'dashboard' | 'tasks' | 'ai-chat' | 'files' | 'calendar' | 'analytics' | 'settings';

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Todo' | 'In Progress' | 'Done';
  dueDate: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface FileItem {
  id: string;
  name: string;
  size: string;
  type: 'pdf' | 'doc' | 'image' | 'folder';
  lastModified: string;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  role: string;
  userCode?: string;
}

export interface AuthUser extends UserProfile {
  userCode: string;
}
