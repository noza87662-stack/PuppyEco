
import { create } from 'zustand';
import { Task, TabType, Message, FileItem, UserProfile, AuthUser } from './types';

interface AppState {
  activeTab: TabType;
  darkMode: boolean;
  isLoggedIn: boolean;
  currentUser: AuthUser | null;
  tasks: Task[];
  messages: Message[];
  files: FileItem[];
  setActiveTab: (tab: TabType) => void;
  toggleDarkMode: () => void;
  addTask: (task: Task) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  addMessage: (msg: Message) => void;
  setTasks: (tasks: Task[]) => void;
  registerUser: (name: string, email: string) => string;
  loginUser: (code: string) => boolean;
  logout: () => void;
  checkSession: () => void;
}

const STORAGE_KEY_USERS = 'puppy_eco_users';
const STORAGE_KEY_SESSION = 'puppy_eco_session';

const getStoredUsers = (): AuthUser[] => {
  const stored = localStorage.getItem(STORAGE_KEY_USERS);
  return stored ? JSON.parse(stored) : [];
};

export const useAppStore = create<AppState>((set, get) => ({
  activeTab: 'dashboard',
  darkMode: true, // Default to dark for the new aesthetic
  isLoggedIn: false,
  currentUser: null,
  tasks: [
    { id: '1', title: 'Design System Update', description: 'Revamp the core UI components for v3.0', priority: 'High', status: 'In Progress', dueDate: '2023-12-24' },
    { id: '2', title: 'Puppy Bot Training', description: 'Fine-tune the emotional support module', priority: 'Medium', status: 'Todo', dueDate: '2023-12-28' },
    { id: '3', title: 'Q4 Report', description: 'Prepare performance metrics for stakeholder meeting', priority: 'Low', status: 'Todo', dueDate: '2024-01-05' }
  ],
  messages: [
    { id: 'start', role: 'assistant', content: "Woof! I'm your Puppy Assistant. How are you feeling today? I'm here to help you work and stay happy!", timestamp: new Date() }
  ],
  files: [
    { id: 'f1', name: 'Strategy_2024.pdf', size: '2.4 MB', type: 'pdf', lastModified: '2 days ago' },
    { id: 'f2', name: 'Brand_Assets', size: '450 MB', type: 'folder', lastModified: '1 week ago' },
    { id: 'f3', name: 'UI_Mockups.jpg', size: '12 MB', type: 'image', lastModified: '3 hours ago' }
  ],
  setActiveTab: (tab) => set({ activeTab: tab }),
  toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
  addTask: (task) => set((state) => ({ tasks: [...state.tasks, task] })),
  updateTask: (id, updates) => set((state) => ({
    tasks: state.tasks.map(t => t.id === id ? { ...t, ...updates } : t)
  })),
  deleteTask: (id) => set((state) => ({
    tasks: state.tasks.filter(t => t.id !== id)
  })),
  addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
  setTasks: (tasks) => set({ tasks }),

  registerUser: (name, email) => {
    const code = Math.random().toString(36).substring(2, 10).toUpperCase();
    const newUser: AuthUser = {
      name,
      email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
      role: 'Member',
      userCode: code
    };
    const users = getStoredUsers();
    users.push(newUser);
    localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
    return code;
  },

  loginUser: (code) => {
    const users = getStoredUsers();
    const user = users.find(u => u.userCode === code);
    if (user) {
      set({ isLoggedIn: true, currentUser: user });
      localStorage.setItem(STORAGE_KEY_SESSION, code);
      return true;
    }
    return false;
  },

  logout: () => {
    set({ isLoggedIn: false, currentUser: null, activeTab: 'dashboard' });
    localStorage.removeItem(STORAGE_KEY_SESSION);
  },

  checkSession: () => {
    const sessionCode = localStorage.getItem(STORAGE_KEY_SESSION);
    if (sessionCode) {
      const users = getStoredUsers();
      const user = users.find(u => u.userCode === sessionCode);
      if (user) {
        set({ isLoggedIn: true, currentUser: user });
      }
    }
  }
}));
